from django.shortcuts import render
from django.http import HttpResponse, Http404
from .models import Player, Batter, Pitcher
from .truevalue import TVbatter, TVpitcher, Pointsbatter, Pointspitcher
from django.shortcuts import render
import json
import os


def fantasy_tool(request):
    allplayers = Player.objects.all()
    return render(request, "fantasy_tool.html")

def fantasy_batters(request):
    sorted_batters = Batter.objects.all()
    with open (os.getcwd() + '/extractor/data/batters.json') as data_fileb:
        response_data = json.load(data_fileb)
        datab = response_data
        for row in datab:
            row = dict(row)
            Batter.name = row['info']['full']
            Batter.pos = row['info']['pos']
            Batter.points = row['batting']['fp']
            Batter.runs = row['batting']['runs']
            Batter.single = row['batting']['single']
            Batter.double = row['batting']['double']
            Batter.triple = row['batting']['triple']
            Batter.homers = row['batting']['homers']
            Batter.rbi = row['batting']['rbi']
            Batter.sb = row['batting']['sb']
            Batter.bb = row['batting']['bb']
            Batter.ks = row['batting']['ks']
            Batter.TVb = row['batting']['Tvb']
            sorted_batters = (Batter.objects.all())
        print (Batter)
        sorted_batters = sorted(
        sorted_batters, key=lambda batter: batter.TVb, reverse=True)
    context = {"sorted_batters": sorted_batters}
    return render(request, "fantasy_batters.html", context)

def fantasy_pitchers(request):
    sorted_pitchers = Pitcher.objects.all()
    with open (os.getcwd()+ '/extractor/data/pitchers.json') as data_filep:
        response_data = json.load(data_filep)
        datap = response_data
        for row in datap:
            row = dict(row)
            Pitcher.name = row['info']['full']
            Pitcher.pos = row['info']['full']
            Pitcher.points = row['pitching']['fp']
            Pitcher.ip = row['pitching']['ip']
            Pitcher.ws = row['pitching']['ws']
            Pitcher.ls = row['pitching']['ls']
            Pitcher.cg = row['pitching']['cg']
            Pitcher.sho = row['pitching']['sho']
            Pitcher.sv = row['pitching']['sv']
            Pitcher.er = row['pitching']['er']
            Pitcher.hr = row['pitching']['hr']
            Pitcher.bb = row['pitching']['bb']
            Pitcher.ks = row['pitching']['ks']
            Pitcher.hld = row['pitching']['hld']
            Pitcher.Tvp = row['pitching']['Tvp']
            #sorted_pitchers.append(Pitcher)
            print (Pitcher.name)
    sorted_pitchers = sorted(
        sorted_pitchers, key=lambda pitcher: pitcher.TVp, reverse=True
    )
    context = {"sorted_pitchers": sorted_pitchers}
    return render(request, "fantasy_pitchers.html", context)


def blog(request):
    return render(request, "blog.html", {})


def about(request):
    return render(request, "about.html", {})
