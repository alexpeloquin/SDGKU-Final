from django.urls import path
from extractor.views import fantasy_tool, fantasy_batters, fantasy_pitchers, blog, about


urlpatterns = [
    path("", fantasy_tool, name="fantasy_tool"),
    path("batters", fantasy_batters, name="fantasy_batters"),
    path("pitchers", fantasy_pitchers, name="fantasy_pitchers"),
    path("about", about, name="about"),
    path("blog", blog, name="blog"),
]
