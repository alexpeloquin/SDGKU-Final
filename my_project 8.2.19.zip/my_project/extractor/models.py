from django.db import models


class Player(models.Model):
    name = models.CharField(max_length=30)
    pos = models.CharField(max_length=30, null=True)
    points = models.IntegerField()

    def __unicode__(self):
        return self.name


class Batter(models.Model):
    name = models.CharField(max_length=30)
    pos = models.CharField(max_length=30, null=True)
    points = models.IntegerField()
    runs = models.IntegerField()
    single = models.IntegerField()
    double = models.IntegerField()
    triple = models.IntegerField()
    homers = models.IntegerField()
    rbi = models.IntegerField()
    sb = models.IntegerField()
    bb = models.IntegerField()
    ks = models.IntegerField()
    TVb = models.IntegerField(null=True)

    def __unicode__(self):
        return self.name


class Pitcher(models.Model):
    name = models.CharField(max_length=30)
    pos = models.CharField(max_length=30, null=True)
    points = models.IntegerField()
    ip = models.IntegerField()
    ws = models.IntegerField()
    ls = models.IntegerField()
    cg = models.IntegerField()
    sho = models.IntegerField()
    sv = models.IntegerField()
    er = models.IntegerField()
    hr = models.IntegerField()
    bb = models.IntegerField()
    ks = models.IntegerField()
    hld = models.IntegerField()
    TVp = models.IntegerField(null=True)

    def __unicode__(self):
        return self.name
