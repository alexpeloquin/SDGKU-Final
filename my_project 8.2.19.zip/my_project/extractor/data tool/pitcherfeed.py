from ohmysportsfeedspy import MySportsFeeds
import json
import csv
import auth
import math

pitching = {}
player = {"info": 0, "pitching": 0}
info = {}
pitchers = {}


Data_query = MySportsFeeds("1.2", verbose=True)
Data_query.authenticate("d001dbaf-4587-4fcd-972d-d0e5b8", "BosoxPats1819")
Output = Data_query.msf_get_data(
    league="mlb",
    season="2019-regular",
    position="P,SP,RP",
    feed="cumulative_player_stats",
    format="json",
    force="true",
)

filename = "../data/stats_pitchers.csv"
f = open(filename, "w+")
f.close()

with open('results/cumulative_player_stats-mlb-2019-regular.json') as f:
    pdata = json.load(f)
    pitcherdata = pdata["cumulativeplayerstats"]["playerstatsentry"]
    with open('../data/stats_pitchers.csv', 'a') as f:
        dict_writer = csv.DictWriter(f, player.keys())
        dict_writer.writeheader()
    for item in pitcherdata:
        playerinfo = item["player"]
        first = playerinfo["FirstName"]
        last = playerinfo["LastName"]
        pos = playerinfo["Position"]
        full = first + " " + last
        info["full"] = full
        info["pos"] = pos
        player["info"] = info
        ip = item['stats']["InningsPitched"]['#text']
        ws = item['stats']["Wins"]['#text']
        ls = item['stats']["Losses"]['#text']
        cg = item['stats']["CompletedGames"]['#text']
        sho = item['stats']["Shutouts"]['#text']
        sv = item['stats']["Saves"]['#text']
        er = item['stats']["EarnedRunsAllowed"]['#text']
        hr = item['stats']["HomerunsAllowed"]['#text']
        bb = item['stats']["PitcherWalks"]['#text']
        ks = item['stats']["PitcherStrikeouts"]['#text']
        hld = item['stats']["Holds"]['#text']
        ipoint = float(ip)
        ipoint = math.modf(ipoint)
        a = ipoint[0]
        b = ipoint[1]
        a = a * 3.3
        a = round(a, 2)
        ipreal = (float(a)+int(b))
        fp = (float(ipreal)*1 + int(ws)*5 + int(ls)*-3 + int(cg)*5 + int(sho)*5 + int(sv)
              * 3.5 + int(er)*-1 + int(hr)*-.5 + int(bb)*-.5 + int(ks)*1 + int(hld)*1.5)
        fp = round(fp, 2)
        Tvp = (float(ipreal)*1.1 + int(ws)*1.25 + int(ls)*-.75 + int(cg)*5.5 + int(sho)*6
         + int(sv)*.75 + int(er)*-1.1 + int(hr)*-.65 + int(bb)*-.75 + int(ks)*1.5)
        Tvp = round(Tvp, 2)
        pitching['fp'] = fp
        pitching['ip'] = ip
        pitching['ws'] = ws
        pitching['ls'] = ls
        pitching['cg'] = cg
        pitching['sho'] = sho
        pitching['sv'] = sv
        pitching['er'] = er
        pitching['hr'] = hr
        pitching['bb'] = bb
        pitching['ks'] = ks
        pitching['hld'] = hld
        pitching['Tvp'] = Tvp
        player["pitching"] = pitching
        with open('../data/stats_pitchers.csv', 'a') as f:
            dict_writer = csv.DictWriter(f, player.keys())
            dict_writer.writerow(player)
