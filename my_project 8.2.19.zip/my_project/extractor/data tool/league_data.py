hpk = [
    {'gameid': 388, 'leagueid': 11178},
]

