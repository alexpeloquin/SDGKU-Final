import auth
import csv
import datetime
from league_data import hpk
from yahoo_oauth import OAuth2
import json
from json import dumps

all_owned = []


def get_owned():
    with open("../data/query_rosters.csv") as csvDataFile:
        csvReader = csv.reader(csvDataFile, delimiter=",")
        next(csvReader)
        for row in csvReader:
            fname = row[23]
            lname = row[24]
            pos = row[8]
            player = fname + " " + lname
            all_owned.append(player)
        return all_owned