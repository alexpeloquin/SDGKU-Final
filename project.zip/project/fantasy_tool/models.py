from django.db import models

# Create your models here.

# class Player(models.Model):
#     id = models.ForeignKey()
#     name = models.CharField(max_length=30)
#     point = model.IntegerField()

# class Batter(models.Model):
#     id = model.ForeignKey(Player)
#     name = models.CharField(max_length=30)
#     points = models.IntegerField()
#     runs = models.IntegerField()
#     single = models.IntegerField()
#     double = models.IntegerField()
#     triple = models.IntegerField()
#     homers = models.IntegerField()
#     rbi = models.IntegerField()
#     sb = models.IntegerField()
#     bb = models.IntegerField()
#     ks = models.IntegerField()
#     cyc = models.IntegerField()

# class Pitcher(models.Model):
#     id = model.ForeignKey(Player)
#     name = models.CharField(max_length=30)
#     ip = models.IntegerField()
#     ws = models.IntegerField()
#     ls = models.IntegerField()
#     cg = models.IntegerField()
#     sho = models.IntegerField()
#     sv = models.IntegerField()
#     er = models.IntegerField()
#     hr = models.IntegerField()
#     bb = models.IntegerField()
#     ks = models.IntegerField()
#     cyc = models.IntegerField()
#     hld = models.IntegerField()
#     nh = models.IntegerField()
#     pg = models.IntegerField()

