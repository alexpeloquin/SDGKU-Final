from django.shortcuts import render
from django.http import HttpResponse, Http404
from .models import Player, Batter, Pitcher
from .truevalue import TVbatter

# Create your views here.
def fantasy_tool(request):
    allplayers = Player.objects.all()
    return render(request, "fantasy_tool.html", {"allplayers": allplayers})


def fantasy_batters(request):
    Formula = TVbatter()
    allbatters = Batter.objects.all()
    for Batter in allbatters:
        x = Batter.TVb
        print(x)
        Batter.TVb = Formula.truevalue(x)
        Batter.objects.all().update(tvb = truevalue.truevalue(TVb))
    return render(request, "fantasy_batters.html", {"allbatters": allbatters})


def fantasy_pitchers(request):
    allpitchers = Pitcher.objects.all()
    return render(request, "fantasy_pitchers.html", {"allpitchers": allpitchers})

def blog(request):
    return render(request, "blog.html", {})


def about(request):
    return render(request, "about.html", {})

