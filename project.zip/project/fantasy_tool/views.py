from django.shortcuts import render
from django.http import HttpResponse,Http404

# Create your views here.
def fantasy_tool(request):
    return render(request, "fantasy_tool.html", {})

def fantasy_batters(request):
    return render(request, "fantasy_batters.html", {})

def fantasy_pitchers(request):
    return render(request, "fantasy_pitchers.html", {})
