class TVbatter:
    runs = 1
    def truevalue(self, runs, single, double, triple, homers, rbi, sb, bb, ks, cyc):
        tvb = 0
        r = runs * 1.1
        s = single * 1
        d = double * 2.1
        t = triple * 4.2
        h = homers * 5.2
        rbi = rbi * .75
        sb = sb * 2.1
        bb = bb * 1
        ks = ks * -.5
        cyc = cyc * 10
        tvb = r + s + d + t + h + rbi + sb + bb + ks + cyc
        return tvb
        


        

    