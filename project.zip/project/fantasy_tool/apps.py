from django.apps import AppConfig


class FantasyToolConfig(AppConfig):
    name = 'fantasy_tool'
