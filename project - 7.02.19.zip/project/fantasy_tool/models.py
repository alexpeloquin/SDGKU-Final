from django.db import models

# Create your models here.


class Player(models.Model):
    name = models.CharField(max_length=30)
    points = models.IntegerField()

    def __unicode__(self):
        return self.name


class Batter(models.Model):
    name = models.CharField(max_length=30)
    points = models.IntegerField()
    runs = models.IntegerField()
    single = models.IntegerField()
    double = models.IntegerField()
    triple = models.IntegerField()
    homers = models.IntegerField()
    rbi = models.IntegerField()
    sb = models.IntegerField()
    bb = models.IntegerField()
    ks = models.IntegerField()
    cyc = models.IntegerField()
    TVb = models.IntegerField(null=True)

    def __unicode__(self):
        return self.name


class Pitcher(models.Model):
    name = models.CharField(max_length=30)
    points = models.IntegerField()
    ip = models.IntegerField()
    ws = models.IntegerField()
    ls = models.IntegerField()
    cg = models.IntegerField()
    sho = models.IntegerField()
    sv = models.IntegerField()
    er = models.IntegerField()
    hr = models.IntegerField()
    bb = models.IntegerField()
    ks = models.IntegerField()
    hld = models.IntegerField()
    nh = models.IntegerField()
    pg = models.IntegerField()
    TVp = models.IntegerField(null=True)

    def __unicode__(self):
        return self.name

