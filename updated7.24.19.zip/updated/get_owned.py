import auth
import csv
import datetime
from league_data import hpk
from yahoo_oauth import OAuth2
import json
from json import dumps
from classes.basic_player import BasicPlayer

all_owned = []

def get_owned():
    with open('data/rosters.csv') as csvDataFile:
        csvReader = csv.reader(csvDataFile, delimiter=",")
        next(csvReader)
        for row in csvReader:
            fname = row[18]
            lname = row[19]
            pos = row[10]
            player = fname + "-" + lname
            all_owned.append(player)
        print(len(all_owned))
        return all_owned
