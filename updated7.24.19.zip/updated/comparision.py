import json
import csv

fpitcher = []
dict_list = []

input_file = csv.DictReader(open("data/batterstats.csv"))
for row in input_file:
    print (row)




# with open ('data/uniques_pitchers.csv') as f:
#     csvReader = csv.reader(f, delimiter=",")
#     for row in csvReader:
#         name = row[0]
#         print (name)

# def csv_dict_list(vfile):
#     reader = csv.DictReader(open(vfile, 'r'))
#     for r in reader:
#         print (r)
#         fpitcher.append(r)
#     print (fpitcher)




# with open ('data/uniques_batters.csv') as f:
#     csvReader = csv.reader(f, delimiter=",")
#     for row in csvReader:
#         name = row[0]
#         print (name)
#         with open ('data/batterstats.csv') as g:
#             csvReader2 = csv.DictReader(g)
#             for row in csvReader2:
#                 print (row)
#                 # if name == row['full']:
#                 #     fpitcher.append(row)
#                 #     print (fpitcher)




