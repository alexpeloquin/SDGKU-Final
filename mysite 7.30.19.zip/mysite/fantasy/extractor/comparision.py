import json
import csv
import collections
import ast
import sqlite3

unique_batters = []
batters = {}
fbatter = []

unique_pitchers = []
pitchers = {}
fpitcher = []


with open ('data/YFA_batters.csv') as a:
    csvReader = csv.reader(a, delimiter=",")
    for row in csvReader:
        name = row[0]
        unique_batters.append(name)
    print (len(unique_batters))
    with open('data/stats_batters.csv') as b:
        reader = csv.DictReader(b)
        for row in reader:
            c = collections.OrderedDict(row)
            d = c['batting']
            e = ast.literal_eval(d)
            f = c['info']
            g = ast.literal_eval(f)
            h = g['full']
            if h in unique_batters:
                batters["info"] = g
                batters['batting'] = e
                fbatter.append(dict(batters))
        fullbatters = json.dumps(fbatter)
        f = open('data/batters.json', 'w')
        f.write(fullbatters)

with open ('data/YFA_pitchers.csv') as i:
    csvReader = csv.reader(i, delimiter=",")
    for row in csvReader:
        name = row[0]
        unique_pitchers.append(name)
    print (len(unique_pitchers))
    with open('data/stats_pitchers.csv') as j:
        reader = csv.DictReader(j)
        for row in reader:
            k = collections.OrderedDict(row)
            l = k['pitching']
            m = ast.literal_eval(l)
            n = k['info']
            o = ast.literal_eval(n)
            p = o['full']
            if p in unique_pitchers:
                pitchers["info"] = o
                pitchers['pitching'] = m
                fpitcher.append(dict(pitchers))
        fullpitchers = json.dumps(fpitcher)
        f = open('data/pitchers.json', 'w')
        f.write(fullpitchers)
