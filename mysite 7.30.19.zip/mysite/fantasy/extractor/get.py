import os
import csv
import datetime
import auth
from league_data import hpk
from auth import OAuth2
import json
from json import dumps
from get_owned import get_owned
import unidecode

b = open("data/YFA_pitchers.csv", "w")
b.truncate()
b.close

p = open("data/YFA_batters.csv", "w")
p.truncate()
p.close

all_owned = get_owned()
all_players = []
matched = []
uniques_batters = []
uniques_pitchers = []

csv.register_dialect("ALM", delimiter=",", quoting=csv.QUOTE_ALL)
y = auth.yahoo_session()
oauth = OAuth2(None, None, from_file="oauth2.json")
if not oauth.token_is_valid():
    oauth.refresh_access_token()

# once player and position extracted from Yahoo API and appended to all_players using player_data function below, function is run to compare player full name against player full name in all_owned
# if full name is matched to a name in all_owned, then object sent to "matched" list. Else, if unmatched player has a P in his position he goes to unique pitchers, if no P, then to unique.batters
def search_name_in_owned(name):
    found = False
    for player in all_owned:
        if(player == name):
            return True            
    return False        

# strings game id and league id together for intial call 
def make_league_code(gameid, leagueid):
    return str(gameid) + ".l." + str(leagueid)

# makes call to API and returns 25 players starting from start=0
def player_data(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=0"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []
 

def player_data2(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=26"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data2(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []



def player_data3(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=51"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data3(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data4(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=76"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data4(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data5(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=101"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data5(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data6(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=126"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data6(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data7(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=151"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data7(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data8(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=176"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data8(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data9(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=201"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data9(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data10(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=226"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data10(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []
    print ("*"*20 +"10 down, 50 to go" + "*"*20 )

def player_data12(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=251"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data12(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data13(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=276"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data13(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data14(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=301"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data14(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data15(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=326"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data15(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data17(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=351"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data17(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data18(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=376"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data18(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data19(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=401"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data19(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data20(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=426"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data20(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []
    print ("*"*20 +"20 down, 40 to go" + "*"*20 )

def player_data21(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=451"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data21(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data22(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=476"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data22(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data23(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=501"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data23(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data24(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=526"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data24(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data25(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=551"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data25(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data26(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=576"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data26(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data27(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=601"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data27(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data28(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=626"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data28(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data29(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=651"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data29(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data30(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=676"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data30(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

    print ("*"*20 +"30 down, 30 to go" + "*"*20 )

def player_data31(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=701"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data31(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data32(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=726"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data32(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data33(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=751"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data33(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data34(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=776"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data34(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data35(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=801"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data35(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data36(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=826"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data36(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data37(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=851"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data37(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data38(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=876"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data38(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data39(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=901"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data39(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data40(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=926"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data40(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []
    print ("*"*20 +"40 down, 20 to go" + "*"*20 )

def player_data41(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=951"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data41(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data42(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=976"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data42(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data43(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1001"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data43(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data44(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1026"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data44(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data45(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1051"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data45(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data46(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1076"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data46(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data47(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1101"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data47(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data48(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1126"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data48(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data49(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1151"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data49(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data50(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1176"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data50(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []
    print ("*"*20 +"50 down, 10 to go" + "*"*20 )

def player_data51(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1201"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data51(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data52(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1226"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data52(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data53(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1251"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data53(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data54(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1276"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data54(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data55(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1301"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data55(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []


def player_data56(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1326"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data56(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []
    print ("*"*20 +"so close now" + "*"*20 )

def player_data57(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1351"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data57(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data58(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1376"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data58(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data59(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1401"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data59(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []

def player_data60(league_code):
    return (
        "https://fantasysports.yahooapis.com/fantasy/v2/league/"
        + league_code
        + "/players;start=1426"
    )

for i in hpk:
    league_code = make_league_code(i["gameid"], i["leagueid"])
    l = auth.api_query(y, player_data60(league_code))
    players_dict = l["fantasy_content"]["league"]["players"]["player"]
    counter = 0
    while counter < 25:
        player_info = players_dict[counter]
        players_fname = player_info["name"]["first"]
        players_lname = player_info["name"]["last"]
        players_name = players_fname + " " + players_lname
        players_name = unidecode.unidecode(players_name)
        all_players.append(players_name)
        player_pos = player_info["eligible_positions"]["position"]
        all_players.append(player_pos)
        all_players.append("\n")
        # check if the name (players_name) exist inside the all_owned
        if(search_name_in_owned(players_name)):
            matched.append(players_name)# store the full name
        else:
            # if the player is unique, then parsed based on postion into batters and pitchers lists
            if('P' in player_pos[0]):
                uniques_pitchers.append(players_name + "," + player_pos[0])
            else:
                uniques_batters.append(players_name + "," + player_pos[0])
        counter = counter + 1
    # write the uniques in a line by line fashion
    with open('data/YFA_pitchers.csv', 'a') as the_file:
        for pitcher in uniques_pitchers:
            the_file.write(pitcher + '\n')
    with open('data/YFA_batters.csv', 'a') as the_file:
        for batter in uniques_batters:
            the_file.write(batter + '\n')
    uniques_batters = []
    uniques_pitchers = []
