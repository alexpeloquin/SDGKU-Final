from ohmysportsfeedspy import MySportsFeeds
import json
import csv
import auth
import math

batting = {}
player = {"info": 0, "batting": 0}
info = {}
batters = {}

Data_query = MySportsFeeds("1.2", verbose=True)
Data_query.authenticate("d001dbaf-4587-4fcd-972d-d0e5b8", "BosoxPats1819")
Output = Data_query.msf_get_data(
    league="mlb",
    season="2019-regular",
    position="C,1B,2B,3B,SS,LF,CF,RF,DH,OF",
    feed="cumulative_player_stats",
    format="json",
    force="true",
)

filename = "data/stats_batters.csv"
f = open(filename, "w+")
f.close()

with open('results/cumulative_player_stats-mlb-2019-regular.json') as f:
    bdata = json.load(f)
    batterdata = bdata["cumulativeplayerstats"]["playerstatsentry"]
    with open('data/stats_batters.csv', 'a') as f:
        dict_writer = csv.DictWriter(f, player.keys())
        dict_writer.writeheader()
    for thing in batterdata:
        playerinfo = thing["player"]
        first = playerinfo["FirstName"]
        last = playerinfo["LastName"]
        pos = playerinfo["Position"]
        full = first + " " + last
        info["full"] = full
        info["pos"] = pos
        player["info"] = info
        runs = thing['stats']["Runs"]['#text']
        hit = thing['stats']["Hits"]['#text']
        double = thing['stats']["SecondBaseHits"]['#text']
        triple = thing['stats']["ThirdBaseHits"]['#text']
        homers = thing['stats']["Homeruns"]['#text']
        rbi = thing['stats']['RunsBattedIn']['#text']
        sb = thing['stats']["StolenBases"]['#text']
        bb = thing['stats']["BatterWalks"]['#text']
        ks = thing['stats']["BatterStrikeouts"]['#text']
        single = int(hit) - int(double) - int(triple) - int(homers)
        fp = (int(runs)*1 + int(single)*1 + int(double)*2 + int(triple)*4 + int(homers)*5 + int(rbi)*1 + int(sb)*2 + int(bb)*.75 + int(ks)*-.75)
        batting['fp']=fp
        batting['runs']=runs
        batting['single']=single
        batting['double']=double
        batting['triple']=triple
        batting['homers']=homers
        batting['rbi']=rbi
        batting['sb']=sb
        batting['bb']=bb
        batting['ks']=ks
        player["batting"] = batting
        with open('data/stats_batters.csv', 'a') as f:
            dict_writer = csv.DictWriter(f, player.keys())
            dict_writer.writerow(player)
