from django.contrib import admin
from .models import Player, Batter, Pitcher

admin.site.register(Player)
admin.site.register(Batter)
admin.site.register(Pitcher)

# Register your models here.
