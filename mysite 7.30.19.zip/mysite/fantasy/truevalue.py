class TVbatter:
    def truevalue(self, runs, single, double, triple, homers, rbi, sb, bb, ks, cyc):
        tvb = 0
        r = runs * 1.1
        s = single * 1
        d = double * 2.1
        t = triple * 4.2
        h = homers * 5.2
        rbi = rbi * 0.75
        sb = sb * 2.1
        bb = bb * 1
        ks = ks * -0.5
        cyc = cyc * 10
        tvb = r + s + d + t + h + rbi + sb + bb + ks + cyc
        return tvb


class TVpitcher:
    def truevalue(self, ip, ws, ls, cg, sho, sv, er, hr, bb, ks, hld, nh, pg):
        tvp = 0
        ip = ip * 1.1
        ws = ws * 1.25
        ls = ls * -0.75
        cg = cg * 5.5
        sho = sho * 6
        sv = sv * 0.75
        er = er * -1.1
        hr = hr * -0.65
        bb = bb * -0.75
        ks = ks * 1.3
        hld = hld * 1.5
        nh = nh * 2
        pg = pg * 2.5
        tvp = ip + ws + ls + cg + sho + sv + er + hr + bb + ks + hld + nh + pg
        return tvp

