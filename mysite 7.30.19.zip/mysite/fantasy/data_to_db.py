import os
import sys
import sqlite3
import json
from .models import Player, Batter, Pithcer


# import Player, Batter, Pitcher
# from fantasy.models import Player, Batter, Pitcher
# from . import models


sorted_batters = Batter.objects.all()
with open("extractor/data/batters.json") as data_file:
    data = json.load(data_file)
    for row in data:
        row = dict(row)
        Batter.name = row['info']["full"]
        print (Batter.name)

    