from django.shortcuts import render
from django.http import HttpResponse, Http404
from .models import Player, Batter, Pitcher
from .truevalue import TVbatter, TVpitcher


# Create your views here.
def fantasy_tool(request):
    allplayers = Player.objects.all()
    return render(request, "fantasy_tool.html")


with open("extractor/data/batters.json") as data_file:
    data = json.load(data_file)
    Batter.name = info[0]
    


def fantasy_batters(request):
    # Line below calls from DB
    sorted_batters = Batter.objects.all()
    for batter in sorted_batters:
        Formula = TVbatter()
        x = Formula.truevalue(
            batter.runs,
            batter.single,
            batter.double,
            batter.triple,
            batter.homers,
            batter.rbi,
            batter.sb,
            batter.bb,
            batter.ks,
            batter.cyc,
        )
        # x = x - batter.points
        batter.TVb = float(round(x, 2))
        print(batter.TVb)
        batter.save()
    sorted_batters = sorted(sorted_batters, key=lambda batter: batter.TVb, reverse=True)
    context = {"sorted_batters": sorted_batters}
    return render(request, "fantasy_batters.html", context)


def fantasy_pitchers(request):
    sorted_pitchers = Pitcher.objects.all()
    for pitcher in sorted_pitchers:
        Formula = TVpitcher()
        x = Formula.truevalue(
            pitcher.ip,
            pitcher.ws,
            pitcher.ls,
            pitcher.cg,
            pitcher.sho,
            pitcher.sv,
            pitcher.er,
            pitcher.hr,
            pitcher.bb,
            pitcher.ks,
            pitcher.hld,
            pitcher.nh,
            pitcher.pg,
        )
        # x = x - pitcher.points
        pitcher.TVp = float(round(x, 2))
        print(pitcher.TVp)
        pitcher.save()
    sorted_pitchers = sorted(
        sorted_pitchers, key=lambda pitcher: pitcher.TVp, reverse=True
    )
    context = {"sorted_pitchers": sorted_pitchers}
    return render(request, "fantasy_pitchers.html", context)


def blog(request):
    return render(request, "blog.html", {})


def about(request):
    return render(request, "about.html", {})
