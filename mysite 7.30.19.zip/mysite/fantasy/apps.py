from django.apps import AppConfig


class FantasyConfig(AppConfig):
    name = 'fantasy'
