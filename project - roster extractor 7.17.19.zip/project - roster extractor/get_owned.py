import auth
import csv
import datetime
from league_data import hpk
from yahoo_oauth import OAuth2
import json
from json import dumps

all_owned = []

with open ('rosters.csv') as csvDataFile:
    csvReader = csv.reader(csvDataFile, delimiter=",")
    for row in csvReader:
        all_owned.append(row[17])
        all_owned.append(row[10] +"\n")
        with open("all_owned", "w") as resultFle:
            wr = csv.writer(resultFle, dialect="excel")
            wr.writerow(all_owned)

# with open ('rosters', 'r') as csvinput:
#                 with open ("all_players_owned", 'w') as csvoutput:
#                         writer = csv.writer(csvoutput,lineterminator=',')
#                         reader = csv.reader(csvinput)
#                         all = []
#                         row = next(reader)
#                         all.append(row)
#                         for x in reader:
#                                 print (x)
#                                 row.append(row[0])
#                                 all.append(row)
#                         print (reader)
#                         writer.writerows(all)