import csv


owned = "all_owned"
players = "all_players"

with open(owned) as first:
    rd = csv.DictReader(first)
    for row in rd:
        print (rd)
        print (row)
        print ('hello')