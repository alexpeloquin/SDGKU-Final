import auth
import csv
import datetime
from league_data import hpk
from yahoo_oauth import OAuth2
import json
from json import dumps


all_players = []
all_rows = []

csv.register_dialect("ALM", delimiter=",", quoting=csv.QUOTE_ALL)
y = auth.yahoo_session()
oauth = OAuth2(None, None, from_file="oauth2.json")
if not oauth.token_is_valid():
    oauth.refresh_access_token()

def make_league_code(gameid, leagueid):
    return str(gameid) + ".l." + str(leagueid)

def player_data(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=0"

def player_data2(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=26"

def player_data3(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=51"

def player_data4(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=76"

def player_data5(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=101"

def player_data6(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=126"

def player_data7(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=151"

def player_data8(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=176"

def player_data9(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=201"

def player_data10(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=225"

def player_data11(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=251"

def player_data12(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=276"

def player_data13(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=301"

def player_data14(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=326"

def player_data15(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=351"

def player_data16(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=376"

def player_data17(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=401"

def player_data18(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=426"

def player_data19(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=451"

def player_data20(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=476"
        
def player_data21(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=501"

def player_data22(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=526"

def player_data23(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=551"

def player_data24(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=576"

def player_data25(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=601"

def player_data26(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=626"

def player_data27(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=651"

def player_data28(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=676"

def player_data29(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=701"

def player_data30(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=726"

def player_data31(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=751"

def player_data32(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=676"

def player_data33(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=701"

def player_data34(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=726"

def player_data35(league_code):
        return "https://fantasysports.yahooapis.com/fantasy/v2/league/" + league_code + "/players;start=751"

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data2(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data4(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data5(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data6(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data7(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data8(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)
for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data9(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data10(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data11(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data12(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data13(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data14(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data15(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data16(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data17(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)
for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data18(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data19(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data20(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data21(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data22(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data23(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data24(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data25(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data26(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data27(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)
for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data28(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data29(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data30(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data31(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)
        
for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data32(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data33(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data34(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)

for i in hpk:
        league_code = make_league_code(i["gameid"], i["leagueid"])
        l = auth.api_query(y, player_data35(league_code))
        players_dict = l['fantasy_content']['league']['players']['player']
        counter =0
        while counter <25:
                player_info = players_dict[counter]
                players_list = player_info['name']['full']
                print (players_list)
                all_players.append(players_list)
                counter = counter + 1
        with open ("all_players", "w",) as resultFle:
                wr = csv.writer(resultFle, dialect='excel')
                wr.writerow(all_players)


        # Place list into CSV insert into columns

        # with open ('all_rows', 'r') as csvinput:
        #         with open ("all_players", 'w') as csvoutput:
        #                 writer = csv.writer(csvoutput,lineterminator=',')
        #                 reader = csv.reader(csvinput)
        #                 all = []
        #                 row = next(reader)
        #                 all.append(row)
        #                 for x in reader:
        #                         print (x)
        #                         row.append(row[0])
        #                         all.append(row)
        #                 print (reader)
        #                 writer.writerows(all)

                    
# auth.data_to_csv(
#     target_dir="data",
#     data_to_write=all_players,
#     desired_name='all_players'
# )

# for i in hpk:
#     #counter = 0
#     #while counter < 3:
#         # get league data
#         league_code = make_league_code(i["gameid"], i["leagueid"])
#         #scounter = str(counter)
#         l = auth.api_query(y, player_data1(league_code))
#         players_list = l['fantasy_content']['league']['players']
#         all_players.append(players_list)
#         print (all_players)
#      #   counter =+1