hpk = [
    #2019
    {'gameid': 388, 'leagueid': 11178},
]