import json
import csv
import collections
import ast


fbatter = []
dict_list = []
pitchers = {}
batters = {}
player = []

unique_batters = []
stat_batters = []

# Would to see which of the uniques that were not matched
with open ('data/uniques_batters.csv') as f:
    csvReader = csv.reader(f, delimiter=",")
    for row in csvReader:
        name = row[0]
        unique_batters.append(name)
    print (len(unique_batters))
    with open('data/batterstats.csv') as f:
        reader = csv.DictReader(f)
        for row in reader:
            a = collections.OrderedDict(row)
            f = a['batting']
            g = ast.literal_eval(f)
            # print (g)
            # print (type(g))
            b = a['info']
            c = ast.literal_eval(b)
            d = c['full']
            for d in unique_batters:
                batters["info"] = c
                batters['batting'] = g
                fbatter.append(batters)
                print (fbatter)
        fullbatters = json.dumps(batters)
        f = open('data/batters.json', 'w')
        f.write(fullbatters)
        f.close

            
        
#       mport json

# dict = {'Python' : '.py', 'C++' : '.cpp', 'Java' : '.java'}

# json = json.dumps(dict)
# f = open("dict.json","w")
# f.write(json)
# f.close()
  






# # Would to see which of the uniques that were not matched
# with open ('data/uniques_batters.csv') as f:
#     csvReader = csv.reader(f, delimiter=",")
#     for row in csvReader:
#         name = row[0]
#         unique_batters.append(name)
#     print (len(unique_batters))
#     with open('data/batterstats.csv') as f:
#         reader = csv.DictReader(f)
#         for row in reader:
#             a = collections.OrderedDict(row)
#             b = a['info']
#             c = ast.literal_eval(b)
#             d = c['full']
#             stat_batters.append(d)
#             # Player is a list with dicts with all the players stats
#             player.append(a)
#         print (len(stat_batters))
#     # unique_batters and stat_batters are each lists with only the full name
#     e = set(unique_batters) & set(stat_batters)
#     #print (e)
#     print (len(e))
#     # Need a dict that consist of full record of names on [e] from either player or batterstats.csv 
#     print (player)