class BasicPlayer:
    full_name = ""
    position = ""

    def __init__(self, name, position):
        self.full_name = name
        self.position = position
